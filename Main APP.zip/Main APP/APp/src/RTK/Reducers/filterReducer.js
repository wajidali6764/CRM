const initialState = "66f5c52fa219e6d1deef087a";
const filterReducer = (state = initialState, action) => {
  switch (action.type) {
    case "FILTER":
      return action.value;
    default:
      return state;
  }
};

export default filterReducer;
