const isLoadingAction = (value) => {
  return { type: "LOADER", value };
};

export default isLoadingAction;
