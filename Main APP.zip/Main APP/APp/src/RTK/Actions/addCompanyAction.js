const addCompanyAction = (value) => {
  return { type: "ADDCOMANY", value };
};

export default addCompanyAction;
