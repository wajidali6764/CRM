const filterAction = (value) => {
    return { type: "FILTER", value };
  };
  
  export default filterAction;
  