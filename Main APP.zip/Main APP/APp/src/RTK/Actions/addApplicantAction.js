const addApplicantAction = (value) => {
  return { type: "ADDAPPLICANT", value };
};

export default addApplicantAction;
