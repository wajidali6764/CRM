const gridColumnAction = (value) => {
  return { type: "SWAPING", value };
};

export default gridColumnAction;
