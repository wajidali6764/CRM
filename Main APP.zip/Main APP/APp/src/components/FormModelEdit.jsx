import addApplicantAction from "../RTK/Actions/addApplicantAction";
import { useDispatch, useSelector } from "react-redux";
import { RxCrossCircled } from "react-icons/rx";
import axios from "axios";
import { useEffect, useState } from "react";
import isLoadingAction from "../RTK/Actions/isLoadingAction";

const FormModelEdit = ({ isOpen, onClose, value }) => {
  const userId = useSelector((state) => state.filterReducer);
  const isLoading = useSelector((state) => state.isLoadingReducer);
  const [editValues, setEditValues] = useState(value);
  const dispatch = useDispatch();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      dispatch(isLoadingAction(true));
      const EDIT_EMP = `http://localhost:3500/api/users/${userId}/employees/${value._id}`;
      await axios.put(
        EDIT_EMP,
        JSON.stringify({
          _id: editValues._id,
          firstName: editValues.firstName,
          lastName: editValues.lastName,
          phoneNumber: editValues.phoneNumber,
          cnic: editValues.cnic,
          email: editValues.email,
          desiredCountry: editValues.desiredCountry,
          IELTS_PTE_Score: editValues.IELTS_PTE_Score,
          dateOfBirth: editValues.dateOfBirth,
          passport: editValues.passport,
          bachelor: editValues.bachelor,
          masterDegree: editValues.masterDegree,
          grade10: editValues.grade10,
          grade12DAE: editValues.grade12DAE,
        }),
        {
          headers: { "Content-Type": "application/json" },
          withCredentials: true,
        }
      );
      const GET_EMP = `http://localhost:3500/api/users/${userId}/employees`;
      const response = await axios.get(GET_EMP);
      dispatch(addApplicantAction(response?.data));
    } catch (err) {
      if (!err?.response) {
        console.log("No Server Response");
      } else if (err.response?.status === 409) {
        console.log("Username Taken");
      } else {
        console.log("Registration Failed");
      }
    } finally {
      dispatch(isLoadingAction(false));
    }
    onClose();
  };

  // Sync state with the new value when the component opens or the value prop changes
  useEffect(() => {
    if (isOpen) {
      setEditValues(value);
    }
  }, [isOpen, value]);

  return (
    <>
      <div
        className={`fixed top-0 z-50 left-0  w-full h-full flex justify-end bg-[#717D8C] bg-opacity-25 ${
          isOpen ? "" : "hidden"
        }`}
      >
        <div className="overflow-scroll fixed top-0 right-0 sidebar_animation  bg-[#F9FBFD] p-5 lg:w-[500px] md:w-[500px] sm:w-[500px] h-full rounded">
          <div className="flex justify-between border-b pb-3">
            <h3 className="font-semibold text-lg">Edit Applicant</h3>
            <button
              onClick={onClose}
              className="font-semibold text-gray-400 text-[32px]"
            >
              <RxCrossCircled />
            </button>
          </div>
          <form className="mt-5 text-sm" onSubmit={handleSubmit}>
            <div className="grid md:grid-cols-2 md:gap-6">
              <div className="relative z-0 w-full mb-5 group">
                <label htmlFor="firstName">
                  First Name:
                  <span className="text-red-700 text-[15px]"> *</span>
                </label>
                <input
                  type="text"
                  name="firstName"
                  id="firstName"
                  className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                  placeholder="First Name"
                  value={editValues.firstName}
                  onChange={(e) =>
                    setEditValues({
                      ...editValues,
                      ["firstName"]: e.currentTarget.value,
                    })
                  }
                  required
                />
              </div>
              <div className="relative z-0 w-full mb-5 group">
                <label htmlFor="lastName">
                  Last Name:
                  <span className="text-red-700 text-[15px]"> *</span>
                </label>
                <input
                  type="text"
                  name="lastName"
                  id="lastName"
                  className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                  placeholder="Last Name"
                  value={editValues.lastName}
                  onChange={(e) =>
                    setEditValues({
                      ...editValues,
                      ["lastName"]: e.currentTarget.value,
                    })
                  }
                  required
                />
              </div>
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="email">
                Email Address:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="email"
                id="email"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="Eami@gmail.com"
                value={editValues.email}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    ["email"]: e.currentTarget.value,
                  })
                }
                required
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="number">
                Phone Number:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="phoneNumber"
                id="phoneNumber"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="Enter Phone Number"
                value={editValues.phoneNumber}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    ["phoneNumber"]: e.currentTarget.value,
                  })
                }
                required
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="cnic">
                C.N.I.C Number:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="cnic"
                id="cnic"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="C.N.I.C Number"
                value={editValues.cnic}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    ["cnic"]: e.currentTarget.value,
                  })
                }
                required
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="desiredCountry">Desired country for study:</label>
              <input
                type="text"
                name="desiredCountry"
                id="desiredCountry"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                value={editValues.desiredCountry}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    ["desiredCountry"]: e.currentTarget.value,
                  })
                }
                placeholder="Enter desired country"
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="IELTS_PTE_Score">IELTS/PTE Score:</label>
              <input
                type="text"
                name="IELTS_PTE_Score"
                id="IELTS_PTE_Score"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                value={editValues.IELTS_PTE_Score}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    ["IELTS_PTE_Score"]: e.currentTarget.value,
                  })
                }
                placeholder="Enter Score"
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="dateOfBirth">
                Date Of Birth:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="date"
                name="dateOfBirth"
                id="dateOfBirth"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder=""
                value={editValues.dateOfBirth}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    ["dateOfBirth"]: e.currentTarget.value,
                  })
                }
                required
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="passport">
                Passport Number:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="passport"
                id="passport"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                value={editValues.passport}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    ["passport"]: e.currentTarget.value,
                  })
                }
                placeholder="Passport Number"
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="grade10">Grade 10:</label>
              <input
                type="text"
                name="grade10"
                id="grade10"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="%"
                value={editValues.grade10}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    ["grade10"]: e.currentTarget.value,
                  })
                }
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="grade12DAE">Grade 12 / D.A.E:</label>
              <input
                type="text"
                name="grade12DAE"
                id="grade12DAE"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="%"
                value={editValues.grade12DAE}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    ["grade12DAE"]: e.currentTarget.value,
                  })
                }
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="bachelor">Bachelor:</label>
              <input
                type="text"
                name="bachelor"
                id="bachelor"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="Bachelor"
                value={editValues.bachelor}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    ["bachelor"]: e.currentTarget.value,
                  })
                }
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="masterDegree">Master Degree% / CGPA:</label>
              <input
                type="text"
                name="masterDegree"
                id="masterDegree"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="Master degree"
                value={editValues.masterDegree}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    ["masterDegree"]: e.currentTarget.value,
                  })
                }
              />
            </div>

            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="masterDegree"> CV </label>
              <input
                type="file"
                name="masterDegree"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                id="masterDegree"
                placeholder=" "
              />
            </div>
            <button
              type="submit"
              className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-9 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
            >
              {isLoading ? "Loading..." : "Save Edit"}
            </button>
          </form>
        </div>
      </div>
    </>
  );
};

export default FormModelEdit;
