import { useEffect, useState } from "react";
import { FaPlus } from "react-icons/fa6";
import TableDemo from "./TableDemo";
import FormStructure from "./FormStructure";
import axios from "axios";
import isLoadingAction from "../RTK/Actions/isLoadingAction";
import { useDispatch } from "react-redux";

const Companies = () => {
  const [isModelOpen, setIsModelOpen] = useState(false);
  const [tableData, setTableData] = useState([]);
  const dispatch = useDispatch();
  const openModel = () => {
    setIsModelOpen(true);
  };
  const closeModel = () => {
    setIsModelOpen(false);
  };
  const tableHeader = ["NAME", "URL", "EMAIL", "SCORE", " "];
  const tableScheme = [["name"], ["url"], ["email"], ["score"]];
  useEffect(() => {
    const GET_USER = "http://localhost:3500/api/users/all";
    const request = async () => {
      try {
        dispatch(isLoadingAction(true));
        const response = await axios.get(GET_USER);
        setTableData(response?.data);
      } catch (err) {
        console.error(err);
      } finally {
        dispatch(isLoadingAction(false));
      }
    };
    request();
  }, []);
  return (
    <>
      <FormStructure isOpen={isModelOpen} onClose={closeModel} />
      <TableDemo
        tableHeader={tableHeader}
        tableScheme={tableScheme}
        tableData={tableData}
        status={false}
      />
      <button
        className="fixed bottom-2 right-2 md:bottom-7 md:right-2"
        onClick={openModel}
      >
        <div className="border p-4 bg-[#2C7BE5] rounded-[100%]">
          <FaPlus className="bg-[#2C7BE5] text-white text-xl font-bold" />
        </div>
      </button>
    </>
  );
};

export default Companies;
