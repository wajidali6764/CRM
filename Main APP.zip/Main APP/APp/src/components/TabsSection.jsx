import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import AddApplicants from "./AddApplicants";
import Dashboard from "./Dashboard";
import Companies from "./Companies";

const TabsSection = () => {
  return (
    <>
      <div className="px-3 md:px-5 pt-5">
        <Tabs defaultValue="dashboard">
          <TabsList className="flex justify-start font-semibold mb-5">
            <TabsTrigger
              value="dashboard"
              className="text-zinc-600 hover:text-zinc-400 tracking-wide"
            >
              Dashboard
            </TabsTrigger>
            <TabsTrigger
              value="addApplicants"
              className="text-zinc-600 hover:text-zinc-400 tracking-wide"
            >
              Applicants
            </TabsTrigger>
            <TabsTrigger
              value="company"
              className="text-zinc-600 hover:text-zinc-400 tracking-wide"
            >
              Clients
            </TabsTrigger>
          </TabsList>
          <TabsContent value="dashboard">
            <Dashboard />
          </TabsContent>
          <TabsContent value="addApplicants">
            <AddApplicants />
          </TabsContent>
          <TabsContent value="company">
            <Companies />
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

export default TabsSection;
