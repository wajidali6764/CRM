import React from "react";
import Card from "./Card";
import DataChart from "./DataChart";
import { IoWalletOutline } from "react-icons/io5";
import { IoCallOutline } from "react-icons/io5";
import { LuDollarSign } from "react-icons/lu";
import { CiUser } from "react-icons/ci";

const Dashboard = () => {
  const cardData = [
    {
      title: "Total Leades",
      value: 1,
      icon: <CiUser className="bg-white" />,
    },
    {
      title: "Total Contacts",
      value: 2,
      icon: <IoCallOutline className="bg-white" />,
    },
    {
      title: "Detail Closed",
      value: 3,
      icon: <IoWalletOutline className="bg-white" />,
    },
    {
      title: "Revenue Generated",
      value: 4,
      icon: <LuDollarSign className="bg-white" />,
    },
  ];
  return (
    <section className="main-container">
      <div className="flex flex-col justify-around sm:flex-row sm:flex-wrap md:flex-row lg:flex-row gap-4">
        { cardData.map((card, index) => ( <Card key={index} title={card.title} value={card.value} icon={card.icon} /> )) }
      </div>
      <div className="mb-5">
        <DataChart />
      </div>
    </section>
  );
}

export default Dashboard;
