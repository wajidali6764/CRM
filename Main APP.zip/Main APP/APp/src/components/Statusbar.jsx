"use client";

import * as React from "react";

import { Button } from "./components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./components/ui/dropdown-menu";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import { useEffect } from "react";
import addApplicantAction from "../RTK/Actions/addApplicantAction";

export function Statusbar({ emp_id, value }) {
  const [isLoading, setIsLoading] = React.useState(false);
  const [position, setPosition] = React.useState();
  const [status, setStatus] = React.useState();
  const userId = useSelector((state) => state.filterReducer);
  useEffect(() => {
    const request = async () => {
      const PUT_EMP = `http://localhost:3500/api/users/${userId}/employees/${emp_id}`;
      try {
        setIsLoading(true);
        await axios.put(
          PUT_EMP,
          JSON.stringify({ ...value, ["status"]: position }),
          {
            headers: { "Content-Type": "application/json" },
            withCredentials: true,
          }
        );
        const GET_EMP = `http://localhost:3500/api/users/${userId}/employees/${emp_id}`;
        const response = await axios.get(GET_EMP);
        setStatus(response?.data?.status);
      } catch (err) {
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };
    request();
  }, [position]);

  return (
    <div>
      <DropdownMenu>
        <DropdownMenuTrigger className="text-left">
          <Button
            variant="outline"
            className={`${
              status === "Active"
                ? `text-green-400`
                : status === "InActive"
                ? `text-red-400`
                : status === "InPrograces"
                ? `text-blue-400`
                : ``
            }`}
          >
            {isLoading ? "Loading..." : status}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56">
          <DropdownMenuLabel className="text-gray-600">
            Change Status
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuRadioGroup value={position} onValueChange={setPosition}>
            <DropdownMenuRadioItem
              className="cursor-pointer text-green-400 "
              value="Active"
            >
              Active
            </DropdownMenuRadioItem>
            <DropdownMenuRadioItem
              className="cursor-pointer  text-red-400"
              value="InActive"
            >
              InActive
            </DropdownMenuRadioItem>
            <DropdownMenuRadioItem
              className="cursor-pointer  text-blue-400"
              value="InPrograces"
            >
              InPrograces
            </DropdownMenuRadioItem>
          </DropdownMenuRadioGroup>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
