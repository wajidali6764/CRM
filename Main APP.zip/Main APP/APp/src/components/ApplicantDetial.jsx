import { RxCrossCircled } from "react-icons/rx";

const Dumi = ({ isOpen, onClose, value }) => {
  const [data] = value;
  console.log(data);
  return (
    <>
      <div
        className={`fixed top-0 z-50 left-0  w-full h-full flex justify-end bg-[#717D8C] bg-opacity-25 ${
          isOpen ? "" : "hidden"
        }`}
      >
        <div className="overflow-scroll fixed top-0 right-0 sidebar_animation  bg-[#F9FBFD] p-5 lg:w-[500px] md:w-[500px] sm:w-[500px] h-full rounded">
          <div className="flex justify-between border-b pb-3">
            <h3 className="font-semibold text-lg">Applicant Detail</h3>
            <button
              onClick={onClose}
              className="font-semibold text-gray-400 text-[32px]"
            >
              <RxCrossCircled />
            </button>
          </div>
          <form className="mt-5 text-sm">
            <div className="relative z-0 w-full mb-2 group">
              <h3 className="text-sm font-normal tracking-wide text-gray-500">
                First Name.
              </h3>
              <p
                id="last_name"
                className="w-full text-gray-500  text-base font-medium "
              >
                {data.firstName}
              </p>
            </div>

            <div className="relative z-0 w-full mb-3 group">
              <h3 className="text-sm font-normal tracking-wide text-gray-500">
                Last Name.
              </h3>
              <p
                id="last_name"
                className="w-full text-gray-500  text-base font-medium "
              >
                {data.lastName}
              </p>
            </div>

            <div className="relative z-0 w-full mb-5 group mt-3">
              <h3 className="text-sm font-normal tracking-wide text-gray-500">
                Email.
              </h3>
              <p
                id="last_name"
                className="w-full text-gray-500  text-base font-medium "
              >
                {data.email}
              </p>
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <h3 className="text-sm font-normal tracking-wide text-gray-500">
                Phone Number.
              </h3>
              <p
                id="last_name"
                className="w-full text-gray-500  text-base font-medium "
              >
                {data.phoneNumber}
              </p>
            </div>

            <div className="relative z-0 w-full mb-5 group">
              <h3 className="text-sm font-normal tracking-wide text-gray-500">
                CNIC.
              </h3>
              <p
                id="last_name"
                className="w-full text-gray-500  text-base font-medium "
              >
                {data.cnic}
              </p>
            </div>

            <div className="relative z-0 w-full mb-5 group mt-3">
              <h3 className="text-sm font-normal tracking-wide text-gray-500">
                Desired Country for Study
              </h3>
              <p
                id="last_name"
                className="w-full text-gray-500  text-base font-medium "
              >
                {data.desiredCountry}
              </p>
            </div>

            <div className="relative z-0 w-full mb-5 group mt-3">
              <h3 className="text-sm font-normal tracking-wide text-gray-500">
                IELTS/PTE Score
              </h3>
              <p
                id="last_name"
                className="w-full text-gray-500  text-base font-medium "
              >
                {data.IELTS_PTE_Score}
              </p>
            </div>

            <div className="relative z-0 w-full mb-5 group mt-3">
              <h3 className="text-sm font-normal tracking-wide text-gray-500">
                Date of Birth
              </h3>
              <p
                id="last_name"
                className="w-full text-gray-500  text-base font-medium "
              >
                {data.dateOfBirth}
              </p>
            </div>

            <div className="relative z-0 w-full mb-5 group mt-3">
              <h3 className="text-sm font-normal tracking-wide text-gray-500">
                Passport
              </h3>
              <p
                id="last_name"
                className="w-full text-gray-500  text-base font-medium "
              >
                {data.passport}
              </p>
            </div>
            <div className="border border-b border-dashed my-5"></div>
            <div className="relative z-0 w-full mb-5 group mt-3">
              <h3 className="text-sm font-normal tracking-wide text-gray-500">
                Grade 10
              </h3>
              <p
                id="last_name"
                className="w-full text-gray-500  text-base font-medium "
              >
                {data.grade10}
              </p>
            </div>

            <div className="relative z-0 w-full mb-5 group mt-3">
              <h3 className="text-sm font-normal tracking-wide text-gray-500">
                Grade 12 DAE
              </h3>
              <p
                id="last_name"
                className="w-full text-gray-500  text-base font-medium "
              >
                {data.grade12DAE}
              </p>
            </div>

            <div className="relative z-0 w-full mb-5 group mt-3">
              <h3 className="text-sm font-normal tracking-wide text-gray-500">
                Bachelor
              </h3>
              <p
                id="last_name"
                className="w-full text-gray-500  text-base font-medium "
              >
                {data.bachelor}
              </p>
            </div>

            <div className="relative z-0 w-full mb-5 group mt-3">
              <h3 className="text-sm font-normal tracking-wide text-gray-500">
                Master Degree
              </h3>
              <p
                id="last_name"
                className="w-full text-gray-500  text-base font-medium "
              >
                {data.masterDegree}
              </p>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default Dumi;
