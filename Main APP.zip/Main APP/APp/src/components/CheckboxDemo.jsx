"use client"
import { Checkbox } from "./components/ui/checkbox"

function CheckboxDemo() {
  return (  
      <Checkbox id="terms" />
  );
}

export default CheckboxDemo;
