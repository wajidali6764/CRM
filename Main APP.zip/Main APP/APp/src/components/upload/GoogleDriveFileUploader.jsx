import axios from "axios";
import React, { useState } from "react";

function GoogleDriveFileUploader() {


  const handleSubmit = async () => {
    console.log(`Uploading`);

    if (!file) {
      console.log("No file selected");
      return;
    }

    // Create FormData object
    let formData = new FormData();
    formData.append("file", file.data); // Append the file to formData

    try {
      const response = await axios.post(
        "http://localhost:3500/api/upload/upload-file-to-google-drive",
        formData, // Send formData in the request body
        {
          headers: {
            "Content-Type": "multipart/form-data", // Important for file upload
          },
        }
      );

      if (response.data && response.data.response) {
        setUrl(response.data.response.publicUrl); // Set the URL from the response
      } else {
        console.error("Upload failed", response);
      }
    } catch (error) {
      console.error("Error uploading the file", error);
    }
  };


  return (
    <div>
      
    </div>
  );
}

export default GoogleDriveFileUploader;
