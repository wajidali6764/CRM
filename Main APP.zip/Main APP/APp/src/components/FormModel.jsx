import addApplicantAction from "../RTK/Actions/addApplicantAction";
import { useDispatch, useSelector } from "react-redux";
import { RxCrossCircled } from "react-icons/rx";
import { useState } from "react";
import axios from "axios";
import isLoadingAction from "../RTK/Actions/isLoadingAction";
// import GoogleDriveFileUploader from "./upload/GoogleDriveFileUploader";

const FormModel = ({ isOpen, onClose }) => {
  const userId = useSelector((state) => state.filterReducer);
  const isLoading = useSelector((state) => state.isLoadingReducer);
  const [url, setUrl] = useState("");
  const [file, setFile] = useState(null);
  const dispatch = useDispatch();
  const [value, setValue] = useState({
    firstName: "",
    lastName: "",
    phoneNumber: "",
    cnic: "",
    email: "",
    desiredCountry: "",
    IELTS_PTE_Score: "",
    dateOfBirth: "",
    passport: "",
    bachelor: "",
    masterDegree: "",
    grade10: "",
    grade12DAE: "",
    status: "Active",
  });

  const handleFileChange = (e) => {
    const file = {
      preview: URL.createObjectURL(e.target.files[0]),
      data: e.target.files[0], // Actual file data
    };
    setFile(file);
  };
  const handleClick = async () => {
    console.log(`Uploading`);

    if (!file) {
      console.log("No file selected");
      return;
    }

    // Create FormData object
    let formData = new FormData();
    formData.append("file", file.data);

    try {
      const response = await axios.post(
        "http://localhost:3500/api/upload/upload-file-to-google-drive",
        formData, // Send formData in the request body
        {
          headers: {
            "Content-Type": "multipart/form-data", // Important for file upload
          },
        }
      );

      if (response.data && response.data.response) {
        setUrl(response.data.response.publicUrl); // Set the URL from the response
      } else {
        console.error("Upload failed", response);
      }
    } catch (error) {
      console.error("Error uploading the file", error);
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const CREATE_EMP = `http://localhost:3500/api/users/${userId}/employees`;
      dispatch(isLoadingAction(true));
      await axios.post(
        CREATE_EMP,
        JSON.stringify({
          firstName: value.firstName,
          lastName: value.lastName,
          phoneNumber: value.phoneNumber,
          cnic: value.cnic,
          email: value.email,
          desiredCountry: value.desiredCountry,
          IELTS_PTE_Score: value.IELTS_PTE_Score,
          dateOfBirth: value.dateOfBirth,
          passport: value.passport,
          bachelor: value.bachelor,
          masterDegree: value.masterDegree,
          grade10: value.grade10,
          grade12DAE: value.grade12DAE,
          status: value.status,
        }),
        {
          headers: { "Content-Type": "application/json" },
          withCredentials: true,
        }
      );
      const GET_EMP = `http://localhost:3500/api/users/${userId}/employees`;
      const response = await axios.get(GET_EMP);
      dispatch(addApplicantAction(response?.data));
    } catch (err) {
      if (!err?.response) {
        console.log("No Server Response");
      } else if (err.response?.status === 409) {
        console.log("Username Taken");
      } else {
        console.log("Registration Failed");
      }
    } finally {
      dispatch(isLoadingAction(false));
    }
    setValue({
      firstName: "",
      lastName: "",
      phoneNumber: "",
      cnic: "",
      email: "",
      desiredCountry: "",
      IELTS_PTE_Score: "",
      dateOfBirth: "",
      passport: "",
      bachelor: "",
      masterDegree: "",
      grade10: "",
      grade12DAE: "",
      status: "Active",
    });
    onClose();
  };
  return (
    <>
      <div
        className={`fixed top-0 z-50 left-0  w-full h-full flex justify-end bg-[#717D8C] bg-opacity-25 ${
          isOpen ? "" : "hidden"
        }`}
      >
        <div className="overflow-scroll fixed top-0 right-0 sidebar_animation  bg-[#F9FBFD] p-5 lg:w-[500px] md:w-[500px] sm:w-[500px] h-full rounded">
          <div className="flex justify-between border-b pb-3">
            <h3 className="font-semibold text-lg">Add Applicant</h3>
            <button
              onClick={onClose}
              className="font-semibold text-gray-400 text-[32px]"
            >
              <RxCrossCircled />
            </button>
          </div>
          <form className="mt-5 text-sm" onSubmit={handleSubmit}>
            <div className="grid md:grid-cols-2 md:gap-6">
              <div className="relative z-0 w-full mb-5 group">
                <label htmlFor="firstName">
                  First Name:
                  <span className="text-red-700 text-[15px]"> *</span>
                </label>
                <input
                  type="text"
                  name="firstName"
                  id="firstName"
                  className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                  placeholder="First Name"
                  value={value.firstName}
                  onChange={(e) =>
                    setValue({ ...value, ["firstName"]: e.currentTarget.value })
                  }
                  required
                />
              </div>
              <div className="relative z-0 w-full mb-5 group">
                <label htmlFor="lastName">
                  Last Name:
                  <span className="text-red-700 text-[15px]"> *</span>
                </label>
                <input
                  type="text"
                  name="lastName"
                  id="lastName"
                  className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                  placeholder="Last Name"
                  value={value.lastName}
                  onChange={(e) =>
                    setValue({ ...value, ["lastName"]: e.currentTarget.value })
                  }
                  required
                />
              </div>
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="email">
                Email Address:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="email"
                id="email"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="Eami@gmail.com"
                value={value.email}
                onChange={(e) =>
                  setValue({ ...value, ["email"]: e.currentTarget.value })
                }
                required
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="number">
                Phone Number:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="phoneNumber"
                id="phoneNumber"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="Enter Phone Number"
                value={value.phoneNumber}
                onChange={(e) =>
                  setValue({ ...value, ["phoneNumber"]: e.currentTarget.value })
                }
                required
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="cnic">
                C.N.I.C Number:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="cnic"
                id="cnic"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="C.N.I.C Number"
                value={value.cnic}
                onChange={(e) =>
                  setValue({ ...value, ["cnic"]: e.currentTarget.value })
                }
                required
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="desiredCountry">Desired country for study:</label>
              <input
                type="text"
                name="desiredCountry"
                id="desiredCountry"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                value={value.desiredCountry}
                onChange={(e) =>
                  setValue({
                    ...value,
                    ["desiredCountry"]: e.currentTarget.value,
                  })
                }
                placeholder="Enter desired country"
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="IELTS_PTE_Score">IELTS/PTE Score:</label>
              <input
                type="text"
                name="IELTS_PTE_Score"
                id="IELTS_PTE_Score"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                value={value.IELTS_PTE_Score}
                onChange={(e) =>
                  setValue({
                    ...value,
                    ["IELTS_PTE_Score"]: e.currentTarget.value,
                  })
                }
                placeholder="Enter Score"
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="dateOfBirth">
                Date Of Birth:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="date"
                name="dateOfBirth"
                id="dateOfBirth"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder=""
                value={value.dateOfBirth}
                onChange={(e) =>
                  setValue({
                    ...value,
                    ["dateOfBirth"]: e.currentTarget.value,
                  })
                }
                required
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="passport">
                Passport Number:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="passport"
                id="passport"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                value={value.passport}
                onChange={(e) =>
                  setValue({ ...value, ["passport"]: e.currentTarget.value })
                }
                placeholder="Passport Number"
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="grade10">Grade 10:</label>
              <input
                type="text"
                name="grade10"
                id="grade10"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="%"
                value={value.grade10}
                onChange={(e) =>
                  setValue({ ...value, ["grade10"]: e.currentTarget.value })
                }
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="grade12DAE">Grade 12 / D.A.E:</label>
              <input
                type="text"
                name="grade12DAE"
                id="grade12DAE"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="%"
                value={value.grade12DAE}
                onChange={(e) =>
                  setValue({ ...value, ["grade12DAE"]: e.currentTarget.value })
                }
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="bachelor">Bachelor:</label>
              <input
                type="text"
                name="bachelor"
                id="bachelor"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="Bachelor"
                value={value.bachelor}
                onChange={(e) =>
                  setValue({ ...value, ["bachelor"]: e.currentTarget.value })
                }
              />
            </div>

            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="masterDegree">Master Degree% / CGPA:</label>
              <input
                type="text"
                name="masterDegree"
                id="masterDegree"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="Master degree"
                value={value.masterDegree}
                onChange={(e) =>
                  setValue({
                    ...value,
                    ["masterDegree"]: e.currentTarget.value,
                  })
                }
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="file"> CV </label>
              <input
                type="file"
                name="file"
                onChange={handleFileChange}
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                id="file"
                placeholder=""
                required
              />
            </div>
            <button
              type="submit"
              onClick={handleClick}
              className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-9 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
            >
              {isLoading ? "Loading..." : "Save"}
            </button>
          </form>
        </div>
      </div>
    </>
  );
};

export default FormModel;
