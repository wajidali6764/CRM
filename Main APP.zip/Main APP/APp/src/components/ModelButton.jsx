import axios from "axios";
import infinity from "../Assets/infinity.svg";
import addApplicantAction from "../RTK/Actions/addApplicantAction";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import ProfileComponent from "./ProfileComponent";
import isLoadingAction from "../RTK/Actions/isLoadingAction";
import filterAction from "../RTK/Actions/filterAction";

const Model = () => {
  const userId = useSelector((state) => state.filterReducer);
  const [activeId, setActiveId] = useState(userId);
  const [mapCompanyButton, setMapCompanyButton] = useState([]);
  const handleActive = (id) => {
    setActiveId(id);
  };
  const dispatch = useDispatch();
  useEffect(() => {
    const GET_USER = "http://localhost:3500/api/users/all";
    const request = async () => {
      dispatch(isLoadingAction(true));
      try {
        const response = await axios.get(GET_USER);
        setMapCompanyButton(response?.data);
      } catch (err) {
        console.error(err);
      } finally {
        dispatch(isLoadingAction(false));
      }
      try {
        const GET_EMP = `http://localhost:3500/api/users/${userId}/employees`;
        const response1 = await axios.get(GET_EMP);
        dispatch(addApplicantAction(response1?.data));
      } catch (err) {
        console.error(err);
      }
    };
    request();
  }, []);

  const handleClick = (e) => {
    const userId = e.target.id;
    handleActive(userId);
    dispatch(filterAction(userId));
    const GET_EMP = `http://localhost:3500/api/users/${userId}/employees`;
    const request = async () => {
      try {
        dispatch(isLoadingAction(true));
        const response = await axios.get(GET_EMP);
        dispatch(addApplicantAction(response?.data));
      } catch (error) {
        console.error(error);
      } finally {
        dispatch(isLoadingAction(false));
      }
    };
    request();
  };
  return (
    <>
      <div className="py-4 bg-white lg:w-full md:w-full sm:w-full flex justify-between items-center px-5">
        <span className="bg-white">
          <img src={infinity} alt="infinity" className="bg-white h-[70%]" />
        </span>
        <span className="bg-white">
          <ProfileComponent />
        </span>
      </div>
      <div className="w-full">
        <div className="border flex flex-wrap items-center justify-start bg-[#F9FBFD] px-4 py-2 sm:px-6 sm:py-3 text-sm font-semibold text-[#376cff] hover:text-[#4a86d4] cursor-pointer">
          {mapCompanyButton.map((value, index) => (
            <div
              key={index}
              id={value._id}
              onClick={handleClick}
              className={`flex items-center justify-center w-full px-4 py-2 md:w-auto md:py-2 text-gray-500 border border-blue-100 rounded-md mr-3 mb-2 shadow-gray-100 shadow-lg transition-all duration-150 scale-100 ${
                activeId == value._id
                  ? "bg-blue-200"
                  : "hover:scale-105 active:scale-100"
              }`}
            >
              {value.name}
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Model;
