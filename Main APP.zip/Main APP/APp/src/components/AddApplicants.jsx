import addApplicantAction from "../RTK/Actions/addApplicantAction";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { FaPlus } from "react-icons/fa6";
import TableDemo from "./TableDemo";
import FormModel from "./FormModel";
import axios from "axios";

const AddApplicants = () => {
  const userId = useSelector((state) => state.filterReducer);
  const [isModelOpen, setIsModelOpen] = useState(false);
  // const [isLoading, setIsLoading] = useState(true);
  const isLoading = useSelector((state) => state.isLoadingReducer);
  const openModel = () => {
    setIsModelOpen(true);
  };
  const closeModel = () => {
    setIsModelOpen(false);
  };

  const tableData = useSelector((state) => state.addApplicantReducer);
  const tableHeader = [
    "NAME",
    "PHONE NUMBER",
    "C.N.I.C Number",
    "IELTS/PTE Score",
    "Bachelor",
    "Status",
    " ",
  ];
  const tableScheme = [
    ["firstName", "lastName", "email"],
    ["phoneNumber"],
    ["cnic"],
    ["IELTS_PTE_Score"],
    ["bachelor"],
  ];
  return (
    <>
      <FormModel isOpen={isModelOpen} onClose={closeModel} />
      <TableDemo
        tableHeader={tableHeader}
        tableScheme={tableScheme}
        tableData={tableData}
        isLoading={isLoading}
        status={true}
      />
      <button
        className="fixed bottom-2 right-2 md:bottom-7 md:right-2"
        onClick={openModel}
      >
        <div className="border p-4 bg-[#2C7BE5] rounded-[100%]">
          <FaPlus className="bg-[#2C7BE5] text-white text-xl font-bold" />
        </div>
      </button>
    </>
  );
};

export default AddApplicants;
