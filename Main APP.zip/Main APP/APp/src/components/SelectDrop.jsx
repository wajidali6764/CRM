import { GiSettingsKnobs } from "react-icons/gi";
import { useState } from "react";

const SelectDrop = () => {
  const [selectToggle, setSelectToggle] = useState(false);
  const handleClick = () => { setSelectToggle((prev) => !prev) };

  return (
    <>
      <div className="container-fluid relative cursor-pointer">
        <div className="flex items-center justify-center px-5 py-[5px] text-gray-500 border border-blue-100 rounded-md" onClick={handleClick} >
          <span className="inline-block mr-2">
            <GiSettingsKnobs />
          </span>
          Filter
        </div>
        {selectToggle && (
          <div className="absolute top-10 right-0 px-5 py-5 shadow-lg shadow-gray-300 w-[450px] z-50">
            <ul className="w-full text-gray-500 font-medium text-[13px]">
              <li className="flex justify-between mb-3">
                <label htmlFor="firstName" className="tracking-wide pr-3">
                  First Name
                </label>
                <input
                  type="text"
                  name="firstName"
                  id="firstName"
                  className="border px-2 py-2 rounded-sm w-[260px] outline-1 focus:outline-blue-300 font-normal"
                  placeholder="First Name"
                />
              </li>
              <li className="flex justify-between mb-3">
                <label htmlFor="firstName" className="tracking-wide pr-3">
                  Last Name
                </label>
                <input
                  type="text"
                  name="firstName"
                  id="firstName"
                  className="border px-2 py-2 rounded-sm w-[260px] outline-1 focus:outline-blue-300 font-normal"
                  placeholder="Last Name"
                />
              </li>
              <li className="flex justify-between mb-3">
                <label htmlFor="firstName" className="tracking-wide pr-3">
                  Email
                </label>
                <input
                  type="email"
                  name="firstName"
                  id="firstName"
                  className="border px-2 py-2 rounded-sm w-[260px] outline-1 focus:outline-blue-300 font-normal"
                  placeholder="Email"
                />
              </li>
            </ul>
          </div>
        )}
      </div>
    </>
  );
}

export default SelectDrop;
