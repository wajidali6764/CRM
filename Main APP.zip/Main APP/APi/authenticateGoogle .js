// import { google } from "googleapis";

// const authenticateGoogle = () => {
//   const auth = new google.auth.GoogleAuth({
//     keyFile: path.join(__dirname, "../key.json"), // Adjust path as necessary
//     scopes: ["https://www.googleapis.com/auth/drive"],
//   });
//   return auth;
// };
