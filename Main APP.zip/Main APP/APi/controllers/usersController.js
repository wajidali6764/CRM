const User = require('../model/User');

// Create Employee
const createEmployee = async (req, res) => {
  const { managerId } = req.params;
  const newEmployee = req.body;

  try {
    const user = await User.findById(managerId);
    if (!user) {
      return res.status(404).send('Manager not found');
    }
    user.employees.push(newEmployee);
    await user.save();
    res.status(201).send('Employee added successfully');
  } catch (error) {
    res.status(500).send('Error adding employee: ' + error.message);
  }
};


// Delete Employee
const deleteEmployee = async (req, res) => {
    const { managerId, employeeId } = req.params;
  
    try {
      const user = await User.findById(managerId);
      if (!user) {
        return res.status(404).send('Manager not found');
      }
  
      user.employees = user.employees.filter(emp => emp._id.toString() !== employeeId);
      await user.save();
      res.send('Employee deleted successfully');
    } catch (error) {
      res.status(500).send('Error deleting employee: ' + error.message);
    }
  };


// Read Employees
const getAllEmployees = async (req, res) => {
  const { managerId } = req.params;

  try {
    const user = await User.findById(managerId);
    if (!user) {
      return res.status(404).send('Manager not found');
    }
    res.status(200).json(user.employees);
  } catch (error) {
    res.status(500).send('Error fetching employees: ' + error.message);
  }
};

const getAllUsers = async (req, res) => {
  try {
    const user = await User.find();
    if (!user) {
      return res.status(404).send('Manager not found');
    }
    res.status(200).json(user);
  } catch (error) {
    res.status(500).send('Error fetching employees: ' + error.message);
  }
};

// Update Employee
const updateEmployee = async (req, res) => {
  const { managerId, employeeId } = req.params;
  const updatedData = req.body;

  try {
    const user = await User.findById(managerId);
    if (!user) {
      return res.status(404).send('Manager not found');
    }

    const employeeIndex = user.employees.findIndex(emp => emp._id.toString() === employeeId);
    if (employeeIndex === -1) {
      return res.status(404).send('Employee not found');
    }

    user.employees[employeeIndex] = { ...user.employees[employeeIndex]._doc, ...updatedData };
    await user.save();
    res.send('Employee updated successfully');
  } catch (error) {
    res.status(500).send('Error updating employee: ' + error.message);
  }
};

// Get a specific employee by employeeId
const getEmployee = async (req, res) => {
    const { managerId, employeeId } = req.params;
  
    try {
      const user = await User.findById(managerId);
      if (!user) return res.status(404).send('Manager not found');
  
      const employee = user.employees.id(employeeId);
      if (!employee) return res.status(404).send('Employee not found');
  
      res.status(200).json(employee);
    } catch (error) {
      res.status(500).send('Error fetching employee: ' + error.message);
    }
  };
  
// Create a new user (manager and employees)
const createUser = async (req, res) => {
    const { name, url, email, score, employees } = req.body; // Expecting manager and employees in request body
  
    try {
      const newUser = new User({
        name,
        url,
        email,
        score,
        employees, // This can be an array of employee objects
      });

      await newUser.save();
      res.status(201).json(newUser);
    } catch (error) {
      res.status(500).send('Error creating user: ' + error.message);
    }
  };
  

module.exports = {
    createUser,
    getAllUsers,
    getAllEmployees,
    createEmployee,
    deleteEmployee,
    updateEmployee,
    getEmployee,
}