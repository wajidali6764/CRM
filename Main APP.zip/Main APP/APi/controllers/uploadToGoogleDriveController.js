const fs = require("fs"); // Ensure fs is imported
const { google } = require("googleapis");

const uploadToGoogleDrive = async (file, auth) => {
  const fileMetadata = {
    name: file.originalname,
    parents: ["18iTfeRJ8g4VVcrkTKqxSKdNZ0dIKHI8B"], // Change it according to your desired parent folder id
  };

  const media = {
    mimeType: file.mimetype,
    body: fs.createReadStream(file.path),
  };

  const driveService = google.drive({ version: "v3", auth });

  const response = await driveService.files.create({
    requestBody: fileMetadata,
    media: media,
    fields: "id",
  });
  return response;
};

// const deleteFile = (filePath) => {
//   fs.unlink(filePath, () => {
//     console.log("file deleted");
//   });
// };

module.exports = { uploadToGoogleDrive };
