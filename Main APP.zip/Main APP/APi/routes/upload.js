const fs = require("fs");
const express = require("express");
const router = express.Router();
const uploadToGoogleDrive = require("../controllers/uploadToGoogleDriveController");
const multer = require("multer");
const { google } = require("googleapis");
const path = require("path");

// Ensure the uploads directory exists
const uploadsDir = path.join(__dirname, "../uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Initialize multer for handling file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir); // Use the verified upload folder
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Rename the file
  },
});

const upload = multer({ storage: storage });

const authenticateGoogle = () => {
  const auth = new google.auth.GoogleAuth({
    keyFile: path.join(__dirname, "../key.json"), // Path to key.json in the root folder
    scopes: ["https://www.googleapis.com/auth/drive"],
  });
  return auth;
};

// Define a function to delete the file
const deleteFile = (filePath) => {
  fs.unlink(filePath, (err) => {
    if (err) {
      console.error("Failed to delete file:", err);
    } else {
      console.log("File deleted:", filePath);
    }
  });
};

router.post(
  "/upload-file-to-google-drive",
  upload.single("file"), // Middleware to handle single file upload
  async (req, res, next) => {
    try {
      if (!req.file) {
        return res.status(400).send("No file uploaded.");
      }

      const auth = authenticateGoogle(); // Authenticate using GoogleAuth
      const response = await uploadToGoogleDrive.uploadToGoogleDrive(
        req.file,
        auth
      );

      // Delete the file after successfully uploading it to Google Drive
      deleteFile(req.file.path);

      // Send the response back to the client
      res.status(200).json({ response });
    } catch (err) {
      console.error(err);
      res.status(500).send("An error occurred.");
    }
  }
);

module.exports = router;
