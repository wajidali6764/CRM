// routes/userRoutes.js
const express = require("express");
const router = express.Router();
const usersController = require("../../controllers/usersController");
 

// Create a new user with employees
router.post('/', usersController.createUser);

// Get all users with employees
router.get('/all', usersController.getAllUsers);

// Get all employees for a specific user
router.get('/:managerId/employees', usersController.getAllEmployees);

// Create a new employee for a specific user
router.post('/:managerId/employees', usersController.createEmployee);

// Get a specific employee by employeeId
router.get('/:managerId/employees/:employeeId', usersController.getEmployee);

// Update an employee for a specific user
router.put('/:managerId/employees/:employeeId', usersController.updateEmployee);

// Delete an employee for a specific user
router.delete('/:managerId/employees/:employeeId', usersController.deleteEmployee);

module.exports = router;

