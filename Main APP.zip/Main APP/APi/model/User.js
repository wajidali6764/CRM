const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const employeeSchema = new Schema({
  _id: {
    type: mongoose.Schema.Types.ObjectId,
    auto: true,
  },
  firstName: {
    type: String,
    required: true,
  },
  lastName: {
    type: String,
    required: true,
  },
  phoneNumber: {
    type: String,
    required: true,
  },
  cnic: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  desiredCountry: {
    type: String,
    required: true,
  },
  IELTS_PTE_Score: {
    type: String,
    required: true,
  },
  dateOfBirth: {
    type: String,
    required: true,
  },
  passport: {
    type: String,
    required: true,
  },
  bachelor: {
    type: String,
    required: true,
  },
  masterDegree: {
    type: String,
    required: true,
  },
  grade10: {
    type: String,
    required: true,
  },
  grade12DAE: {
    type: String,
    required: true,
  },
  status: {
    type: String,
    required: true,
  },
});

const userSchema = new Schema({
  _id: {
    type: mongoose.Schema.Types.ObjectId,
    auto: true,
  },
  name: {
    type: String,
    required: true,
  },
  url: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  score: {
    type: String,
    required: true,
  },
  employees: [employeeSchema],
});

module.exports = mongoose.model("User", userSchema);
